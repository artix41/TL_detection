function new_image=convolution(kernel, image)
    new_image = conv2(image, kernel);
    